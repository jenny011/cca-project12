import os, sys, json
from Container import *

class Scheduler():
    def __init__(self, timer, jobs_config):
        self.ci = ContainerInterface(timer)
        self.running = {"ferret":False, "freqmine":False, "canneal":False, "blackscholes":False, "fft":False, "dedup":False}

        with open(jobs_config, "r") as jobs_f:
            jobs = json.load(jobs_f)

        # priority list(based on time it takes to finish the job)
        self.priority = []
        for name in ["ferret", "freqmine", "canneal", "blackscholes", "fft", "dedup"]:
            self.priority.append({"container":self.ci.create_container(jobs[name]), "cpus": jobs[name]["cpuset_cpus"], "act_cpus": jobs[name]["cpuset_cpus"]} )

    def remove_all_containers(self):
        for job in self.priority:
            self.ci.remove_container(job["container"])

    def start_one(self, idx):
        self.ci.start_container(self.priority[idx]["container"])
        self.running[self.priority[idx]["container"]] = True

    def update_one(self, idx, cpu):
        if self.running[self.priority[idx]["container"].name]:
            if cpu != self.priority[idx]["act_cpus"]:
                self.ci.update_container(self.priority[idx]["container"], cpu)
                self.priority[idx]["act_cpus"] = cpu

    def pause_one(self,idx):
        if self.running[self.priority[idx]["container"].name]:
            self.ci.pause_container(self.priority[idx]["container"])
            self.running[self.priority[idx]["container"].name] = False

    def unpause_one(self,idx):
        if not self.running[self.priority[idx]["container"].name]:
            self.ci.unpause_container(self.priority[idx]["container"])
            self.running[self.priority[idx]["container"].name] = True

    def is_finished(self, idx):
        return self.ci.is_exited(self.priority[idx]["container"])
