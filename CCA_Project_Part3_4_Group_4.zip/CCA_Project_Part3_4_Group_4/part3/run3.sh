# !/bin/bash

CURR=$PWD
# Export all the environmental vars (including your ethzid)
# comment it out if exported
source $CURR/env3.sh
cd $PART3_YAML_PATH
echo ">>>>> You are in $PART3_YAML_PATH >>>>>"
# 0: dedup
# 1: blackscholes
# 2: ferret
# 3: freqmine
# 4: canneal
# 5: fft
NAME=("dedup" "blackscholes" "ferret" "freqmine" "canneal" "fft")

echo "Running parsec jobs"

for i in 1 2 3 4 5; do
	kubectl create -f part3-parsec/parsec-${NAME[$(($i))]}.yaml
	if [ $? -ne 0 ]; then
		echo "ERROR: ${NAME[$(($i))]} create failed."
		exit 1
	fi
done

kubectl get pods -o wide
sleep 30
kubectl get pods -o wide

for i in 0; do
	kubectl create -f part3-parsec/parsec-${NAME[$(($i))]}.yaml
	if [ $? -ne 0 ]; then
		echo "ERROR: ${NAME[$(($i))]} create failed."
		exit 1
	fi
done

echo "You can run ./kill3.sh to delete all jobs."

#kubectl get jobs;
while true;
	do kubectl get pods -o wide;
	sleep 20;
done

echo "!!!!! MUST delete the cluster after use: run ./delete.sh !!!!!"
